document.addEventListener('DOMContentLoaded', () => {

    // 1. Image Zoom Functionality
    function imageZoom(imgSelector, resultID) {
        const img = document.querySelector(imgSelector);
        const result = document.getElementById(resultID);

        if (!img || !result) return;

        // Create lens
        const lens = document.createElement("DIV");
        lens.setAttribute("class", "img-zoom-lens");

        // Add lens style dynamically if not in CSS
        lens.style.position = "absolute";
        lens.style.border = "1px solid #d4d4d4";
        lens.style.width = "100px";
        lens.style.height = "100px";
        lens.style.backgroundColor = "rgba(255, 255, 255, 0.4)";
        lens.style.cursor = "none";
        lens.style.display = "none";

        // Insert lens
        img.parentElement.insertBefore(lens, img);

        // Calculate ratio
        let cx, cy;

        const setupZoom = () => {
            // Display result to get dimensions
            result.style.display = "block";

            cx = result.offsetWidth / lens.offsetWidth;
            cy = result.offsetHeight / lens.offsetHeight;

            result.style.backgroundImage = `url('${img.src}')`;
            result.style.backgroundSize = (img.width * cx) + "px " + (img.height * cy) + "px";

            result.style.display = "none"; // Hide initially
        };

        // Wait for image to load
        if (img.complete) {
            setupZoom();
        } else {
            img.onload = setupZoom;
        }

        const moveLens = (e) => {
            e.preventDefault();
            result.style.display = "block";
            lens.style.display = "block";

            const pos = getCursorPos(e);
            let x = pos.x - (lens.offsetWidth / 2);
            let y = pos.y - (lens.offsetHeight / 2);

            // Prevent lens from being positioned outside the image
            if (x > img.width - lens.offsetWidth) { x = img.width - lens.offsetWidth; }
            if (x < 0) { x = 0; }
            if (y > img.height - lens.offsetHeight) { y = img.height - lens.offsetHeight; }
            if (y < 0) { y = 0; }

            // Set lens position
            lens.style.left = x + "px";
            lens.style.top = y + "px";

            // Set background position of result
            result.style.backgroundPosition = "-" + (x * cx) + "px -" + (y * cy) + "px";
        };

        const getCursorPos = (e) => {
            let a, x = 0, y = 0;
            e = e || window.event;
            a = img.getBoundingClientRect();
            x = e.pageX - a.left;
            y = e.pageY - a.top;
            x = x - window.pageXOffset;
            y = y - window.pageYOffset;
            return { x: x, y: y };
        };

        const hideZoom = () => {
            result.style.display = "none";
            lens.style.display = "none";
        };

        // Execute function when moving cursor over image or lens
        lens.addEventListener("mousemove", moveLens);
        img.addEventListener("mousemove", moveLens);

        // Hide on mouse leave
        lens.addEventListener("mouseleave", hideZoom);
        img.addEventListener("mouseleave", hideZoom);
    }

    // Initialize zoom if not on mobile
    if (window.innerWidth > 768) {
        imageZoom(".zoom-img", "zoom-result");
    }


    // 2. FAQ Accordion Functionality
    const accordionHeaders = document.querySelectorAll('.accordion-header');

    accordionHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const isActive = item.classList.contains('active');

            // Close all accordions
            document.querySelectorAll('.accordion-item').forEach(accItem => {
                accItem.classList.remove('active');
            });

            // If it wasn't active, open it
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });

    // 3. Simple Thumbnail click (Mock functionality)
    const thumbnails = document.querySelectorAll('.thumbnail');
    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', () => {
            thumbnails.forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
            // Here you would typically swap the main image source
        });
    });

});